<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/modestasv/Projects/laraveldaily/LaravelDaily-StarterKit/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>