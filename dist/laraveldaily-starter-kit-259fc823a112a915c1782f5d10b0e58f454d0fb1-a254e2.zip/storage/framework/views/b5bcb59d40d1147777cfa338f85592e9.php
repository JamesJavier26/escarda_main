<?php echo e($slot); ?>

<?php /**PATH /Users/modestasv/Projects/laraveldaily/LaravelDaily-StarterKit/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>